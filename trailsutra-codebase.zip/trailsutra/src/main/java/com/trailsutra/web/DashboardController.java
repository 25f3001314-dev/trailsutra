package com.trailsutra.web;

import com.trailsutra.audit.AuditService;
import com.trailsutra.tokenisation.TokenisationService;
import com.trailsutra.report.ReportService;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;

@Controller
public class DashboardController {
    private final JdbcTemplate jdbc; private final AuditService audit; private final TokenisationService tokens; private final ReportService reports;
    public DashboardController(JdbcTemplate jdbc, AuditService audit, TokenisationService tokens, ReportService reports){this.jdbc=jdbc;this.audit=audit;this.tokens=tokens;this.reports=reports;}
    @GetMapping("/") public String home(Model model, Authentication auth){
        String caseId="TS-2026-000458";
        model.addAttribute("username",auth.getName()); model.addAttribute("caseId",caseId);
        model.addAttribute("complaint",jdbc.queryForMap("SELECT c.*,ca.status case_status,ca.officer,ca.created_at case_created FROM complaints c JOIN cases ca ON ca.complaint_id=c.id WHERE ca.case_id=?",caseId));
        model.addAttribute("trail",jdbc.queryForList("SELECT t.txn_id,t.src_token,t.dst_token,t.posted_at,t.amount_paise,t.rail,s.display_name src_name,d.display_name dst_name FROM transactions t LEFT JOIN accounts s ON s.token=t.src_token LEFT JOIN accounts d ON d.token=t.dst_token WHERE t.txn_id LIKE 'TX-SUNITA-%' OR t.txn_id IN ('TX-A-B','TX-A-C','TX-A-D','TX-B-E','TX-C-E','TX-D-R') ORDER BY t.posted_at"));
        model.addAttribute("accounts",jdbc.queryForList("SELECT a.token,a.display_name,a.masked_account,a.segment,a.balance_paise,a.monthly_turnover_paise,COALESCE(s.priority_score,CASE WHEN a.display_name='Ramesh Verma' THEN 0.28 WHEN a.display_name='Aggregator E' THEN 0.68 ELSE 0.90 END) risk,COALESCE(s.role,CASE WHEN a.display_name='Ramesh Verma' THEN 'Likely Innocent' WHEN a.display_name='Aggregator E' THEN 'Aggregator candidate' ELSE 'Relay' END) role FROM accounts a LEFT JOIN account_scores s ON s.account_token=a.token AND s.case_id=? WHERE a.display_name IN ('Sunita Devi','Gig worker A','Relay B','Relay C','Relay D','Aggregator E','Ramesh Verma') ORDER BY a.display_name",caseId));
        model.addAttribute("auditRows",jdbc.queryForList("SELECT id,created_at,event_json,event_hash FROM audit_log ORDER BY id DESC LIMIT 10"));
        return "dashboard";
    }
    @GetMapping("/api/audit/verify") @ResponseBody public Map<String,Object> verifyAudit(){return Map.of("valid",audit.verifyChain());}
    @PostMapping("/api/cases/{caseId}/confirm") @ResponseBody public Map<String,Object> confirmLink(@PathVariable String caseId,@RequestBody ConfirmRequest req,Authentication auth){
        if(!auth.getAuthorities().stream().anyMatch(a->a.getAuthority().equals("ROLE_INVESTIGATING_OFFICER"))) throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        Integer exists=jdbc.queryForObject("SELECT COUNT(*) FROM transactions WHERE txn_id=?",Integer.class,req.txnId());if(exists==null||exists==0)throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Transaction not found");
        jdbc.update("MERGE INTO case_links(case_id,txn_id,score,basis,confirmed_by,confirmed_at) KEY(case_id,txn_id) VALUES(?,?,?,?,?,?)",caseId,req.txnId(),req.score(),req.basis(),auth.getName(),Instant.now());jdbc.update("UPDATE cases SET confirmed_txn_id=?,status='MATCHED' WHERE case_id=?",req.txnId(),caseId);audit.append(auth.getName(),"MATCH_CONFIRMED",caseId+"|"+req.txnId()+"|"+req.basis());return Map.of("confirmed",true,"caseId",caseId,"txnId",req.txnId());
    }
    @PostMapping(value="/api/detokenise",consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("hasRole('INVESTIGATING_OFFICER')") @ResponseBody public Map<String,String> detokenise(@RequestBody DetokeniseRequest req, Authentication auth){
        if(req.reason()==null||req.reason().trim().length()<12) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Written reason of at least 12 characters required");
        Integer active=jdbc.queryForObject("SELECT COUNT(*) FROM trail_edges WHERE case_id=? AND (src_token=? OR dst_token=?)",Integer.class,req.caseId(),req.token(),req.token());
        if(active==null||active==0) throw new ResponseStatusException(HttpStatus.FORBIDDEN,"Account is outside the active complaint trail");
        List<Map<String,Object>> vault=jdbc.queryForList("SELECT encrypted_value,nonce FROM token_vault WHERE token=?",req.token());
        audit.append(auth.getName(),"DETOKENISE",req.caseId()+"|"+req.token()+"|"+req.reason());
        if(vault.isEmpty()) return Map.of("masked","(xxxx••••)","status","No vault mapping available");
        return Map.of("value",tokens.decrypt(vault.get(0).get("ENCRYPTED_VALUE").toString(),vault.get(0).get("NONCE").toString()));
    }
    @PostMapping("/api/reviews") @ResponseBody public Map<String,Object> review(@RequestBody ReviewRequest req, Authentication auth){
        if(!auth.getAuthorities().stream().anyMatch(a->a.getAuthority().equals("ROLE_REVIEWER"))) throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        if(req.reason()==null||req.reason().trim().length()<12) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Written reason required");
        Long balance=jdbc.queryForObject("SELECT balance_paise FROM accounts WHERE token=?",Long.class,req.token()); if(balance==null) throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        long lien=Math.min(Math.max(0,req.lienPaise()),balance);
        jdbc.update("INSERT INTO reviews(case_id,account_token,reviewer,decision,reason,lien_paise,reviewed_at) VALUES(?,?,?,?,?,?,?)",req.caseId(),req.token(),auth.getName(),req.decision(),req.reason(),lien,Instant.now());
        audit.append(auth.getName(),"REVIEW_"+req.decision(),req.caseId()+"|"+req.token()+"|lienPaise="+lien);
        return Map.of("saved",true,"lienPaise",lien,"decision",req.decision());
    }
    @GetMapping("/api/cases/{caseId}/transactions") @ResponseBody public List<Map<String,Object>> transactions(@PathVariable String caseId){
        return jdbc.queryForList("SELECT t.txn_id,t.posted_at,t.amount_paise,t.rail,s.display_name src_name,d.display_name dst_name FROM transactions t JOIN cases c ON c.case_id=? JOIN case_links l ON l.case_id=c.case_id AND l.txn_id=t.txn_id LEFT JOIN accounts s ON s.token=t.src_token LEFT JOIN accounts d ON d.token=t.dst_token ORDER BY t.posted_at",caseId);
    }

    @GetMapping(value="/api/reports/{caseId}.pdf",produces="application/pdf") @ResponseBody public byte[] report(@PathVariable String caseId, HttpServletResponse response, Authentication auth){byte[] pdf=reports.createPdf(caseId);response.setHeader("Content-Disposition","attachment; filename=\""+caseId+".pdf\"");audit.append(auth.getName(),"REPORT_DOWNLOADED",caseId);return pdf;}
    @PostMapping(value="/api/reports/{caseId}/verify",consumes=MediaType.APPLICATION_OCTET_STREAM_VALUE,produces=MediaType.APPLICATION_JSON_VALUE) @ResponseBody public Map<String,Object> verifyReport(@PathVariable String caseId,@RequestBody byte[] content){return reports.verify(caseId,content);}
    public record ConfirmRequest(String txnId,double score,String basis){}
    public record DetokeniseRequest(String caseId,String token,String reason){}
    public record ReviewRequest(String caseId,String token,String decision,String reason,long lienPaise){}
}
