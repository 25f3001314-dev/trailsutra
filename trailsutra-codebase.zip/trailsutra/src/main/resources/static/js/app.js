(() => {
  const $ = (s) => document.querySelector(s);
  const money = (paise) => '₹' + (paise / 100).toLocaleString('en-IN', {maximumFractionDigits: 2});
  const nodeData = [
    {data:{id:'sunita',label:'Sunita Devi\n₹1,80,000\n11:02 AM',kind:'victim'}},
    {data:{id:'a',label:'A · Gig worker\n₹1,80,000\n11:03 AM',kind:'relay'}},
    {data:{id:'b',label:'B\n₹60,000\n11:05 AM',kind:'relay'}},
    {data:{id:'c',label:'C\n₹60,000\n11:06 AM',kind:'relay'}},
    {data:{id:'d',label:'D\n₹60,000\n11:07 AM',kind:'relay'}},
    {data:{id:'e',label:'E · Aggregator\n₹1,20,000\n11:10 AM',kind:'aggregator'}},
    {data:{id:'ramesh',label:'Ramesh Verma\n₹45,000',kind:'innocent'}},
    {data:{id:'unobserved1',label:'Unobserved\nBank / Cash',kind:'unobserved'}},
    {data:{id:'unobserved2',label:'Unobserved\nBank / Cash',kind:'unobserved'}}
  ];
  const edges = [
    ['sunita','a','₹1,80,000'],['a','b','₹60,000'],['a','c','₹60,000'],['a','d','₹60,000'],['b','e','₹60,000'],['c','e','₹60,000'],['d','ramesh','₹45,000'],['e','unobserved1','Unobserved'],['d','unobserved2','Unobserved']
  ].map((e,i)=>({data:{id:'edge'+i,source:e[0],target:e[1],label:e[2],weight:i===0?5:3,unobserved:e[2]==='Unobserved'}}));
  const graph = $('#trailGraph');
  if (graph && window.cytoscape) {
    const cy = cytoscape({container:graph,elements:[...nodeData,...edges],layout:{name:'breadthfirst',directed:true,roots:'#sunita',spacingFactor:1.2,padding:20},style:[
      {selector:'node',style:{'label':'data(label)','text-wrap':'wrap','text-max-width':'105px','font-size':10,'text-valign':'center','text-halign':'center','width':76,'height':54,'background-color':'#dbeafe','color':'#17324e','border-width':2,'border-color':'#8fb8dd'}},
      {selector:'node[kind="victim"]',style:{'background-color':'#1677e8','color':'#fff','border-color':'#1677e8'}},
      {selector:'node[kind="relay"]',style:{'background-color':'#ffe1e4','border-color':'#e65c68'}},
      {selector:'node[kind="aggregator"]',style:{'background-color':'#ffead0','border-color':'#f39a24'}},
      {selector:'node[kind="innocent"]',style:{'background-color':'#d8f8e3','border-color':'#39b56a'}},
      {selector:'node[kind="unobserved"]',style:{'background-color':'#f8fafc','border-style':'dashed','border-color':'#94a3b8'}},
      {selector:'edge',style:{'curve-style':'bezier','target-arrow-shape':'triangle','target-arrow-color':'#5e7892','line-color':'#5e7892','width':'data(weight)','label':'data(label)','font-size':9,'text-background-color':'#fff','text-background-opacity':0.9,'text-background-padding':2}},
      {selector:'edge[unobserved]',style:{'line-style':'dashed','line-color':'#a7b4c2','target-arrow-color':'#a7b4c2'}}
    ]});
    cy.on('tap','node',evt=>{const n=evt.target;$('#reasonCard').textContent=n.data('label')+' · Evidence: observed transaction sequence; inspect source rows before making a decision. Unobserved nodes mark a boundary in available records.');
  }
  document.querySelectorAll('.tab').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('.tab').forEach(b=>b.classList.remove('active'));btn.classList.add('active');const fields=$('.fields');if(fields)fields.style.opacity=btn.dataset.tab==='matches'?'0.72':'1';}));
  const matchForm=$('#matchForm'); if(matchForm)matchForm.addEventListener('submit',e=>{e.preventDefault();alert('Candidate results are displayed for officer review. Confirm a transaction before trail generation.');});
  document.querySelectorAll('.select-txn').forEach(b=>b.addEventListener('click',()=>{b.textContent='Selected';b.disabled=true;}));
  document.querySelectorAll('[data-decision]').forEach(btn=>btn.addEventListener('click',async()=>{
    const f=$('#reviewForm'); if(!f.reportValidity())return; const payload={caseId:f.caseId.value,token:f.token.value,decision:btn.dataset.decision,reason:f.reason.value,lienPaise:Math.round(Number(f.lien.value)*100)};
    try{const response=await fetch('/api/reviews',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-TOKEN':document.querySelector('meta[name="_csrf"]')?.content||''},body:JSON.stringify(payload)});if(!response.ok)throw new Error('Review could not be saved. Sign in with a reviewer account.');const result=await response.json();$('#reviewStatus').textContent='Review saved · lien '+money(result.lienPaise); }catch(err){$('#reviewStatus').textContent=err.message;}
  }));
  const auditButton=$('#verifyAudit');if(auditButton)auditButton.addEventListener('click',async()=>{try{const r=await fetch('/api/audit/verify');const d=await r.json();$('#auditStatus').textContent=d.valid?'Audit chain verified':'Audit chain mismatch';}catch(e){$('#auditStatus').textContent='Unable to verify audit chain';}});
  const reportButton=$('#reportButton');if(reportButton)reportButton.addEventListener('click',()=>{window.location.href='/api/reports/TS-2026-000458.pdf';});
})();
